import scrapy


class DnDTextsSpider(scrapy.Spider):
    name = 'texts'

    def start_requests(self):
        urls = []

        with open('G:\Programming\dnd-data-parse-scrapy\links_all.txt', 'r') as fr:
            urls = fr.readlines()

        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    def parse(self, response):
        for text in response.css('ol'):
            yield {
                'text': text.css('li::text').getall()
            }
